from app import db
from app.constants import CATEGORIAS, SEM_CATEGORIA
from app.models import Colecao, Item


class ColecaoService:
    """Regras relacionadas às coleções."""

    @staticmethod
    def cadastrar(nome, descricao=None):
        """Cria uma nova coleção ativa."""
        colecao = Colecao(
            nome=nome.strip(),
            descricao=(descricao or "").strip() or None,
        )

        db.session.add(colecao)
        db.session.commit()

        return colecao

    @staticmethod
    def itens_por_categoria(colecao):
        """Devolve os itens da coleção agrupados por categoria.

        Resultado: lista de (nome_da_categoria, [itens]). As categorias
        fixas vêm primeiro, na ordem do cadastro; depois categorias antigas
        (texto livre) e, por último, "Sem categoria". Só entram categorias
        que têm pelo menos um item.
        """
        itens = (
            Item.query
            .filter_by(colecao_id=colecao.id)
            .order_by(Item.nome)
            .all()
        )

        grupos = {}
        for item in itens:
            nome = (item.categoria or "").strip() or SEM_CATEGORIA
            grupos.setdefault(nome, []).append(item)

        posicao = {nome: i for i, nome in enumerate(CATEGORIAS)}

        def ordem(nome):
            if nome in posicao:
                return (0, posicao[nome], "")
            if nome == SEM_CATEGORIA:
                return (2, 0, "")
            return (1, 0, nome.lower())

        return [(nome, grupos[nome]) for nome in sorted(grupos, key=ordem)]
