from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import CSRFProtect

from config import Config


# Criação da aplicação.
app = Flask(__name__)
app.config.from_object(Config)

# Extensões utilizadas pelo projeto.
db = SQLAlchemy(app)
csrf = CSRFProtect(app)


# Importamos os modelos e as rotas depois da criação do db
# para evitar problemas de importação circular.
from app import models, routes  # noqa: E402, F401


# Cria as tabelas que ainda não existem no banco.
with app.app_context():
    db.create_all()

    # Banco já existente: adiciona a coluna "quantidade" se ainda não houver.
    from sqlalchemy import inspect, text

    colunas = [c["name"] for c in inspect(db.engine).get_columns("itens")]
    if "quantidade" not in colunas:
        db.session.execute(
            text("ALTER TABLE itens ADD COLUMN quantidade INT NOT NULL DEFAULT 1")
        )
        db.session.commit()

    # Empréstimos passam a guardar só o nome digitado (sem perfis).
    # Banco já existente: cria as colunas de nome, copia os nomes dos
    # perfis antigos e remove as colunas solicitante_id / operador_id.
    colunas_emp = [c["name"] for c in inspect(db.engine).get_columns("emprestimos")]
    if "solicitante_nome" not in colunas_emp:
        db.session.execute(text(
            "ALTER TABLE emprestimos ADD COLUMN solicitante_nome "
            "VARCHAR(120) NOT NULL DEFAULT ''"
        ))
        db.session.execute(text(
            "ALTER TABLE emprestimos ADD COLUMN operador_nome "
            "VARCHAR(120) NOT NULL DEFAULT ''"
        ))
        if "solicitante_id" in colunas_emp:
            db.session.execute(text(
                "UPDATE emprestimos e JOIN solicitantes s "
                "ON s.id = e.solicitante_id SET e.solicitante_nome = s.nome"
            ))
            db.session.execute(text(
                "UPDATE emprestimos e JOIN usuarios u "
                "ON u.id = e.operador_id SET e.operador_nome = u.nome"
            ))
        db.session.commit()

    # Remove as chaves estrangeiras e colunas antigas, se ainda existirem.
    for fk in inspect(db.engine).get_foreign_keys("emprestimos"):
        if set(fk["constrained_columns"]) & {"solicitante_id", "operador_id"}:
            db.session.execute(text(
                f"ALTER TABLE emprestimos DROP FOREIGN KEY {fk['name']}"
            ))
    for coluna in ("solicitante_id", "operador_id"):
        if coluna in colunas_emp:
            db.session.execute(text(
                f"ALTER TABLE emprestimos DROP COLUMN {coluna}"
            ))
    db.session.commit()

    # Se a tabela de coleções estiver vazia, cria as duas coleções padrão.
    # Sem isso, o campo "Coleção" do cadastro de item fica sem opções.
    if models.Colecao.query.count() == 0:
        db.session.add_all([
            models.Colecao(
                nome="LEVEL",
                descricao="Coleção principal do acervo LEVEL.",
            ),
            models.Colecao(
                nome="NINJA",
                descricao="Coleção NINJA integrada ao sistema.",
            ),
        ])
        db.session.commit()
