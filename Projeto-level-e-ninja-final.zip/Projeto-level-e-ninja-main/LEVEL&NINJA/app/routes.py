import os
from datetime import date, timedelta
from uuid import uuid4

from flask import (
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from app import app, db
from app.constants import CATEGORIAS, ICONES_CATEGORIA
from app.forms.colecao_form import ColecaoForm
from app.forms.emprestimo_form import EmprestimoForm
from app.forms.item_form import ItemEdicaoForm, ItemForm
from app.models import (
    Colecao,
    Emprestimo,
    Item,
    Solicitante,
    Usuario,
)
from app.services.colecao_service import ColecaoService
from app.services.emprestimo_service import EmprestimoService
from app.services.item_service import ItemService


def salvar_imagem(arquivo):
    """Salva a imagem enviada em static/uploads e devolve o nome do arquivo."""
    if not arquivo or not arquivo.filename:
        return None

    extensao = os.path.splitext(arquivo.filename)[1].lower()
    nome_arquivo = f"{uuid4().hex}{extensao}"

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    arquivo.save(os.path.join(app.config["UPLOAD_FOLDER"], nome_arquivo))

    return nome_arquivo


def remover_imagem(valor):
    """Apaga do disco uma imagem enviada antes (ignora links externos)."""
    if not valor or valor.startswith(("http://", "https://")):
        return

    caminho = os.path.join(
        app.config["UPLOAD_FOLDER"],
        os.path.basename(valor),
    )
    if os.path.isfile(caminho):
        os.remove(caminho)


@app.template_filter("imagem_url")
def imagem_url(valor):
    """Converte o valor salvo no banco em uma URL utilizável."""
    if not valor:
        return None
    if valor.startswith(("http://", "https://")):
        return valor
    return url_for("static", filename=f"uploads/{valor}")


@app.context_processor
def utilidades():
    """Disponibiliza datas úteis para todos os templates."""
    return {
        "ano_atual": date.today().year,
        "today": date.today(),
    }


# Cores usadas para diferenciar as coleções (SB Admin 2).
# A cor depende do id, então não muda quando novas coleções são criadas.
CORES_COLECAO = ["primary", "success", "info", "warning", "danger", "secondary"]


@app.template_filter("cor_colecao")
def cor_colecao(colecao_id):
    """Devolve o nome da cor da coleção a partir do id dela."""
    return CORES_COLECAO[(colecao_id - 1) % len(CORES_COLECAO)]


@app.template_filter("icone_categoria")
def icone_categoria(nome):
    """Devolve a classe do ícone FontAwesome da categoria."""
    return ICONES_CATEGORIA.get(nome, "fa-tag")


@app.route("/")
def dashboard():
    """Exibe os principais indicadores do sistema."""
    emprestimos_ativos = Emprestimo.query.filter_by(
        status="ativo"
    ).count()

    emprestimos_atrasados = Emprestimo.query.filter(
        Emprestimo.status == "ativo",
        Emprestimo.data_prevista_devolucao < date.today(),
    ).count()

    dados = {
        "itens": Item.query.count(),
        "disponiveis": Item.query.filter_by(
            disponivel=True
        ).count(),
        "emprestimos_ativos": emprestimos_ativos,
        "emprestimos_atrasados": emprestimos_atrasados,
    }

    recentes = (
        Emprestimo.query
        .order_by(Emprestimo.id.desc())
        .limit(6)
        .all()
    )

    return render_template(
        "dashboard.html",
        dados=dados,
        recentes=recentes,
    )


@app.route("/acervo")
def acervo():
    """Exibe o acervo e permite pesquisar itens."""
    termo = request.args.get("q", "")
    colecao_id = request.args.get(
        "colecao",
        type=int,
    )

    itens = ItemService.buscar(
        termo,
        colecao_id,
    )

    colecoes = (
        Colecao.query
        .filter_by(ativa=True)
        .order_by(Colecao.nome)
        .all()
    )

    return render_template(
        "acervo/lista.html",
        itens=itens,
        colecoes=colecoes,
        termo=termo,
        colecao_id=colecao_id,
    )


def opcoes_do_formulario(form, item=None):
    """Preenche as opções de Coleção e Categoria do formulário de item.

    Na edição, a coleção atual do item sempre aparece (mesmo inativa) e
    uma categoria antiga, de texto livre, é mantida como opção extra para
    não ser perdida ao salvar.
    """
    filtro = Colecao.ativa.is_(True)
    if item is not None:
        filtro = db.or_(filtro, Colecao.id == item.colecao_id)

    colecoes = Colecao.query.filter(filtro).order_by(Colecao.nome).all()

    form.colecao_id.choices = [(c.id, c.nome) for c in colecoes]

    if item is not None and item.categoria and item.categoria not in CATEGORIAS:
        form.categoria.choices = form.categoria.choices + [
            (item.categoria, f"{item.categoria} (categoria antiga)")
        ]


def dados_do_formulario(form):
    """Converte os campos do formulário de item em um dicionário."""
    return {
        "nome": form.nome.data.strip(),
        "descricao": form.descricao.data,
        "categoria": form.categoria.data,
        "origem_doador": form.origem_doador.data,
        "tipo": form.tipo.data,
        "codigo": (form.codigo.data or "").strip() or None,
        "observacoes": form.observacoes.data,
        "colecao_id": form.colecao_id.data,
        "quantidade": form.quantidade.data,
        "disponivel": form.disponivel.data,
    }


@app.route("/itens/cadastrar", methods=["GET", "POST"])
def cadastrar_item():
    """Exibe e processa o formulário de cadastro de item."""
    form = ItemForm()
    opcoes_do_formulario(form)

    # Vindo da página de uma coleção, já deixa essa coleção selecionada.
    if request.method == "GET":
        colecao_pre = request.args.get("colecao", type=int)
        if colecao_pre in [valor for valor, _ in form.colecao_id.choices]:
            form.colecao_id.data = colecao_pre

    if form.validate_on_submit():
        imagem_salva = salvar_imagem(form.imagem.data)

        dados = dados_do_formulario(form)
        dados["imagem"] = imagem_salva

        try:
            ItemService.cadastrar(dados)
            flash(
                "Item cadastrado com sucesso!",
                "success",
            )
            return redirect(url_for("acervo"))

        except Exception as erro:
            db.session.rollback()
            remover_imagem(imagem_salva)
            flash(
                f"Não foi possível cadastrar o item: {erro}",
                "danger",
            )

    return render_template(
        "item/cadastrar.html",
        form=form,
        item=None,
    )


@app.route("/itens/<int:item_id>/editar", methods=["GET", "POST"])
def editar_item(item_id):
    """Exibe e processa a edição de um item.

    Só quantidade, descrição e observações podem ser alteradas. Os demais
    campos nem fazem parte do formulário e, mesmo que alguém os envie,
    são ignorados.
    """
    item = db.get_or_404(Item, item_id)

    # obj=item preenche o formulário com os dados atuais (só na abertura;
    # ao enviar, valem os valores digitados).
    form = ItemEdicaoForm(obj=item)

    if form.validate_on_submit():
        dados = {
            "quantidade": form.quantidade.data,
            "descricao": form.descricao.data,
            "observacoes": form.observacoes.data,
        }

        try:
            ItemService.atualizar(item, dados)
        except Exception as erro:
            db.session.rollback()
            flash(
                f"Não foi possível atualizar o item: {erro}",
                "danger",
            )
        else:
            flash(
                "Item atualizado com sucesso!",
                "success",
            )
            return redirect(url_for("detalhe_item", item_id=item.id))

    return render_template(
        "item/cadastrar.html",
        form=form,
        item=item,
    )


@app.route("/itens/<int:item_id>")
def detalhe_item(item_id):
    """Exibe os detalhes e o histórico de um item."""
    item = db.get_or_404(Item, item_id)

    historico = (
        Emprestimo.query
        .filter_by(item_id=item.id)
        .order_by(Emprestimo.data_retirada.desc())
        .all()
    )

    return render_template(
        "item/detalhe.html",
        item=item,
        historico=historico,
    )


@app.route("/emprestimos")
def emprestimos():
    """Lista todos os empréstimos."""
    registros = (
        Emprestimo.query
        .order_by(Emprestimo.id.desc())
        .all()
    )

    return render_template(
        "emprestimo/lista.html",
        emprestimos=registros,
    )


@app.route("/emprestimos/novo", methods=["GET", "POST"])
def novo_emprestimo():
    """Página para registrar o empréstimo dos itens marcados no acervo.

    O acervo envia os itens por GET (?item_ids=1&item_ids=2). Ao salvar,
    o próprio formulário reenvia os ids em campos ocultos.
    """
    try:
        item_ids = [int(i) for i in request.values.getlist("item_ids")]
    except ValueError:
        item_ids = []

    itens = []
    if item_ids:
        itens = (
            Item.query
            .filter(Item.id.in_(item_ids))
            .order_by(Item.nome)
            .all()
        )

    if not itens:
        flash(
            "Marque pelo menos um item no acervo para registrar "
            "o empréstimo.",
            "warning",
        )
        return redirect(url_for("acervo"))

    form = EmprestimoForm()
    # Valores iniciais só na primeira abertura da página.
    if request.method == "GET":
        form.data_emprestimo.data = date.today()
        form.data_devolucao.data = date.today() + timedelta(days=7)
        form.status.data = "ativo"

    if form.validate_on_submit():
        try:
            itens_emprestados, solicitante_nome = EmprestimoService.registrar(
                [i.id for i in itens],
                form.solicitante_nome.data,
                form.operador_nome.data,
                form.data_emprestimo.data,
                form.data_devolucao.data,
                form.status.data,
            )
        except ValueError as erro:
            db.session.rollback()
            flash(str(erro), "danger")
        except Exception as erro:
            db.session.rollback()
            flash(
                f"Não foi possível registrar o empréstimo: {erro}",
                "danger",
            )
        else:
            flash(
                f"{len(itens_emprestados)} item(ns) emprestado(s) "
                f"para {solicitante_nome}.",
                "success",
            )
            return redirect(url_for("emprestimos"))

    return render_template(
        "emprestimo/novo.html",
        form=form,
        itens=itens,
    )


@app.route(
    "/emprestimos/<int:emprestimo_id>/devolver",
    methods=["POST"],
)
def devolver_emprestimo(emprestimo_id):
    """Registra a devolução de um empréstimo."""
    emprestimo = db.get_or_404(
        Emprestimo,
        emprestimo_id,
    )

    EmprestimoService.devolver(emprestimo)

    flash(
        "Devolução registrada com sucesso!",
        "success",
    )

    return redirect(url_for("emprestimos"))


@app.route("/colecoes")
def colecoes():
    """Lista as coleções cadastradas."""
    lista = (
        Colecao.query
        .order_by(Colecao.nome)
        .all()
    )

    return render_template(
        "colecoes.html",
        colecoes=lista,
    )


@app.route("/colecoes/<int:colecao_id>")
def detalhe_colecao(colecao_id):
    """Mostra toda a coleção, dividida por categoria."""
    colecao = db.get_or_404(Colecao, colecao_id)
    grupos = ColecaoService.itens_por_categoria(colecao)

    return render_template(
        "colecao/detalhe.html",
        colecao=colecao,
        grupos=grupos,
        total=sum(len(itens) for _, itens in grupos),
    )


@app.route("/colecoes/nova", methods=["GET", "POST"])
def nova_colecao():
    """Exibe e processa o formulário de nova coleção."""
    form = ColecaoForm()

    if form.validate_on_submit():
        try:
            colecao = ColecaoService.cadastrar(
                form.nome.data,
                form.descricao.data,
            )
        except Exception as erro:
            db.session.rollback()
            flash(
                f"Não foi possível criar a coleção: {erro}",
                "danger",
            )
        else:
            flash(
                f"Coleção {colecao.nome} criada! "
                "Ela já aparece nos filtros do Acervo.",
                "success",
            )
            return redirect(url_for("colecoes"))

    return render_template(
        "colecao/nova.html",
        form=form,
    )


@app.route("/usuarios")
def usuarios():
    """Lista os usuários do sistema."""
    lista = (
        Usuario.query
        .order_by(Usuario.nome)
        .all()
    )

    return render_template(
        "usuarios.html",
        usuarios=lista,
    )


@app.route("/solicitantes")
def solicitantes():
    """Lista os solicitantes."""
    lista = (
        Solicitante.query
        .order_by(Solicitante.nome)
        .all()
    )

    return render_template(
        "solicitantes.html",
        solicitantes=lista,
    )
