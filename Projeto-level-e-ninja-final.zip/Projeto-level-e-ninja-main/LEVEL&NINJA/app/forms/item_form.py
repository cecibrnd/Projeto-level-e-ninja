from flask_wtf import FlaskForm
from flask_wtf.file import FileAllowed, FileField
from wtforms import (
    BooleanField,
    IntegerField,
    SelectField,
    StringField,
    SubmitField,
    TextAreaField,
)
from wtforms.validators import (
    DataRequired,
    Length,
    NumberRange,
    Optional,
    ValidationError,
)

from app.constants import CATEGORIAS
from app.models import Item


class ItemEdicaoForm(FlaskForm):
    """Formulário de edição: só quantidade, descrição e observações."""

    quantidade = IntegerField(
        "Quantidade",
        validators=[
            DataRequired(message="Informe a quantidade."),
            NumberRange(min=1, message="A quantidade deve ser pelo menos 1."),
        ],
    )

    descricao = TextAreaField(
        "Descrição",
        validators=[Optional()],
    )

    observacoes = TextAreaField(
        "Observações",
        validators=[Optional()],
    )

    submit = SubmitField("Salvar alterações")


class ItemForm(FlaskForm):
    """Formulário para cadastro e edição de itens."""

    def __init__(self, *args, item_id=None, **kwargs):
        # item_id é informado na edição, para o SKU do próprio item
        # não ser considerado "repetido".
        super().__init__(*args, **kwargs)
        self.item_id = item_id

    nome = StringField(
        "Nome do item",
        validators=[
            DataRequired(),
            Length(max=120),
        ],
    )

    descricao = TextAreaField(
        "Descrição",
        validators=[Optional()],
    )

    categoria = SelectField(
        "Categoria",
        choices=[("", "Selecione a categoria...")]
        + [(c, c) for c in CATEGORIAS],
        validators=[DataRequired(message="Selecione a categoria.")],
    )

    origem_doador = StringField(
        "Origem / Doador",
        validators=[
            Optional(),
            Length(max=120),
        ],
    )

    tipo = StringField(
        "Tipo",
        validators=[
            Optional(),
            Length(max=80),
        ],
    )

    codigo = StringField(
        "SKU",
        validators=[
            Optional(),
            Length(max=80),
        ],
    )

    observacoes = TextAreaField(
        "Observações",
        validators=[Optional()],
    )

    colecao_id = SelectField(
        "Coleção",
        coerce=int,
        validators=[DataRequired()],
    )

    quantidade = IntegerField(
        "Quantidade",
        default=1,
        validators=[
            DataRequired(message="Informe a quantidade."),
            NumberRange(min=1, message="A quantidade deve ser pelo menos 1."),
        ],
    )

    imagem = FileField(
        "Imagem do item",
        validators=[
            Optional(),
            FileAllowed(
                ["jpg", "jpeg", "png", "gif", "webp"],
                "Envie uma imagem (jpg, png, gif ou webp).",
            ),
        ],
    )

    disponivel = BooleanField(
        "Disponível para empréstimo",
        default=True,
    )

    submit = SubmitField("Salvar item")

    def validate_codigo(self, campo):
        """Impede dois itens com o mesmo SKU."""
        codigo = (campo.data or "").strip()
        if not codigo:
            return

        existe = Item.query.filter(Item.codigo == codigo)
        if self.item_id:
            existe = existe.filter(Item.id != self.item_id)

        if existe.first():
            raise ValidationError("Já existe um item com esse SKU.")
