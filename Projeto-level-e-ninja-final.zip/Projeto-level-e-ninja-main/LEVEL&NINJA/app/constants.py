"""Valores fixos usados em vários pontos do sistema."""

# Categorias disponíveis no cadastro de itens (na ordem em que aparecem).
CATEGORIAS = [
    "Jogos",
    "Livros",
    "RPGs",
    "Mangás",
    "HQs",
    "Dados",
    "Cartas",
]

# Ícone (FontAwesome 5) de cada categoria, usado na página da coleção.
ICONES_CATEGORIA = {
    "Jogos": "fa-gamepad",
    "Livros": "fa-book",
    "RPGs": "fa-dragon",
    "Mangás": "fa-book-open",
    "HQs": "fa-mask",
    "Dados": "fa-dice-d20",
    "Cartas": "fa-clone",
}

# Nome do grupo para itens antigos que não têm categoria.
SEM_CATEGORIA = "Sem categoria"
